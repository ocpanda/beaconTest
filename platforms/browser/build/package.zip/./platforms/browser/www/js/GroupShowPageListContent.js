/*function showGroupList(){
	$.ajax{
		url: "http://140.130.35.62/csie40343142/Tour_System_server/php/GroupListAdd.php",
		type: "POST",

	}
}*/